<?php
$host 		= "localhost";
$user 		= "id17148666_cindyvadella";
$password 	= "9DK6WZUX>DA+3ByC";
$dbname 	= "id17148666_tokobuku";
$conn 		= mysqli_connect($host, $user, $password, $dbname);

if(!$conn){
	die("error in connection");}
?>